import { notFound } from 'next/navigation';

export default function CheckoutWithoutId() {
  // Redirecionar para not found
  notFound();
}
